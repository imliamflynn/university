define(function (require, exports, module) {
    "use strict";

    var CommandManager = brackets.getModule("command/CommandManager"),
        EditorManager  = brackets.getModule("editor/EditorManager"),
        Menus          = brackets.getModule("command/Menus");

    
    // Function to run when the menu item is clicked
        
    function basicHTML5Template() {
         var editor = EditorManager.getFocusedEditor();
        if (editor) {
            
   
            var html5_template =
                "<!DOCTYPE html>" + "\n" +
                "<html lang=\"en\">" + "\n" + 
                "<head>" + "\n" +
                "<!-- Created by: ??? on date -->" + "\n" +
                "<meta charset=\"UTF-8\">" + "\n" +
                
                
                "\t" + "<title> Title </title>" + "\n" +
                "</head>" +"\n\n" +
                "\t" + "<body>" + "\n" +
                "\n" +
                "</body>" + "\n" +
                "</html>" +"\n"                
            ;
            
            var insertionPos = editor.getCursorPos();
            editor.document.replaceRange(html5_template, insertionPos);
        }
    }
    
    var COMMAND_ID = "comp112";   // package-style naming to avoid collisions
    CommandManager.register("HTML5 - Basic", COMMAND_ID, basicHTML5Template);


    var menu = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU);
    menu.addMenuItem(COMMAND_ID, [{ "key": "Tab-Shift" }, { "key": "Tab-Shift"}]);
    
    
});                           