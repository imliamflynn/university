# html5-template-brackets

This is a basic extension to import a basic template of html5 in your html file
Just Click Shift+Tab or click on "EDIT > HTML5 Basic"
